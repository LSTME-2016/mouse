1.0 by LSTME 2014
Library from https://github.com/pavelpetrovic/lstme2014internal

